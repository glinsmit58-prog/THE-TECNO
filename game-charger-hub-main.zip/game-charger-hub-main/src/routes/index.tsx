import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useState } from "react";
import {
  Zap, Shield, Clock, Trophy, Search, Gamepad2, Wallet,
  CreditCard, Headphones, ChevronLeft, Star, Sparkles, Flame,
} from "lucide-react";
import heroImg from "@/assets/hero-gaming.jpg";
import pubg from "@/assets/game-pubg.jpg";
import freefire from "@/assets/game-freefire.jpg";
import mlbb from "@/assets/game-mlbb.jpg";
import cod from "@/assets/game-cod.jpg";
import genshin from "@/assets/game-genshin.jpg";
import fortnite from "@/assets/game-fortnite.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "نِيّون — شحن العاب فوري وآمن | أرخص أسعار الجواهر والشدات" },
      { name: "description", content: "شحن العاب فوري لـ ببجي، فري فاير، جواهر، شدات، وUC بأرخص الأسعار وتسليم خلال ثوانٍ. أكثر من 200 لعبة وضمان استرداد." },
      { property: "og:title", content: "نِيّون — منصة شحن العاب الأولى" },
      { property: "og:description", content: "شحن فوري، أسعار منافسة، ودعم 24/7." },
    ],
  }),
  component: HomePage,
});

const games = [
  { name: "PUBG Mobile", tag: "UC", price: "من 3.99$", img: pubg, hot: true },
  { name: "Free Fire", tag: "جواهر", price: "من 1.99$", img: freefire, hot: true },
  { name: "Mobile Legends", tag: "ألماس", price: "من 2.49$", img: mlbb },
  { name: "Call of Duty", tag: "CP", price: "من 4.99$", img: cod, hot: true },
  { name: "Genshin Impact", tag: "بدائيات", price: "من 0.99$", img: genshin },
  { name: "Fortnite", tag: "V-Bucks", price: "من 7.99$", img: fortnite },
];

const features = [
  { icon: Zap, title: "تسليم فوري", desc: "خلال ثوانٍ من الدفع، رصيدك في حسابك" },
  { icon: Shield, title: "دفع آمن 100%", desc: "تشفير بنكي وبوابات معتمدة عالمياً" },
  { icon: Clock, title: "دعم 24/7", desc: "فريق دعم متاح طوال الوقت بالعربي" },
  { icon: Trophy, title: "أرخص الأسعار", desc: "نضاهي أي سعر منافس أو نسترد الفرق" },
];

const steps = [
  { n: "01", icon: Search, title: "اختر لعبتك", desc: "تصفح أكثر من 200 لعبة" },
  { n: "02", icon: Wallet, title: "حدد الباقة", desc: "باقات تناسب جميع اللاعبين" },
  { n: "03", icon: CreditCard, title: "ادفع بأمان", desc: "بطاقة، Apple Pay، أو محفظة" },
  { n: "04", icon: Sparkles, title: "استلم فوراً", desc: "رصيدك يصل خلال ثوانٍ" },
];

function HomePage() {
  const [query, setQuery] = useState("");
  const filtered = games.filter((g) => g.name.toLowerCase().includes(query.toLowerCase()));

  return (
    <div className="relative overflow-x-hidden">
      <Nav />
      <Hero />
      <Marquee />

      {/* Games */}
      <section id="games" className="relative px-6 py-20 md:px-12">
        <div className="mx-auto max-w-7xl">
          <div className="mb-10 flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
            <div>
              <span className="text-sm font-bold tracking-widest text-accent">// أكثر الألعاب طلباً</span>
              <h2 className="mt-2 text-4xl font-black md:text-6xl">
                اشحن لعبتك <span className="text-gradient-neon">المفضلة</span>
              </h2>
            </div>
            <div className="relative w-full md:w-80">
              <Search className="absolute right-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="ابحث عن لعبة..."
                className="w-full rounded-2xl border border-border bg-card/60 py-3 pr-12 pl-4 text-foreground backdrop-blur transition focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/40"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-5 md:grid-cols-3 lg:grid-cols-4">
            {filtered.map((g, i) => (
              <motion.article
                key={g.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.05 }}
                whileHover={{ y: -8 }}
                className="group relative cursor-pointer overflow-hidden rounded-3xl glass"
              >
                <div className="relative aspect-[3/4] overflow-hidden">
                  <img
                    src={g.img}
                    alt={g.name}
                    loading="lazy"
                    width={768}
                    height={1024}
                    className="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-card via-card/40 to-transparent" />
                  {g.hot && (
                    <span className="absolute right-3 top-3 flex items-center gap-1 rounded-full bg-gradient-neon px-3 py-1 text-xs font-bold text-primary-foreground shadow-glow">
                      <Flame className="h-3 w-3" /> رائج
                    </span>
                  )}
                </div>
                <div className="relative space-y-2 p-5">
                  <div className="flex items-center justify-between">
                    <h3 className="font-display text-2xl">{g.name}</h3>
                    <span className="text-xs font-bold text-accent">{g.tag}</span>
                  </div>
                  <div className="flex items-center justify-between pt-2">
                    <span className="text-sm text-muted-foreground">{g.price}</span>
                    <span className="flex items-center gap-1 text-sm font-bold text-primary transition group-hover:gap-2">
                      اشحن الآن <ChevronLeft className="h-4 w-4" />
                    </span>
                  </div>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="relative px-6 py-20 md:px-12">
        <div className="mx-auto max-w-7xl">
          <div className="mb-12 text-center">
            <span className="text-sm font-bold tracking-widest text-accent">// لماذا نِيّون</span>
            <h2 className="mt-2 text-4xl font-black md:text-6xl">
              التجربة <span className="text-gradient-neon">الأفضل</span> في الشحن
            </h2>
          </div>
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="group relative overflow-hidden rounded-3xl glass p-7 transition hover:border-primary/50"
              >
                <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-primary/10 blur-3xl transition group-hover:bg-primary/30" />
                <div className="relative">
                  <div className="mb-5 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-neon shadow-glow">
                    <f.icon className="h-7 w-7 text-primary-foreground" />
                  </div>
                  <h3 className="mb-2 text-xl font-bold">{f.title}</h3>
                  <p className="text-sm leading-relaxed text-muted-foreground">{f.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Steps */}
      <section className="relative px-6 py-20 md:px-12">
        <div className="mx-auto max-w-7xl">
          <div className="mb-16 text-center">
            <span className="text-sm font-bold tracking-widest text-accent">// كيف يعمل</span>
            <h2 className="mt-2 text-4xl font-black md:text-6xl">
              4 خطوات. <span className="text-gradient-neon">دقيقة واحدة</span>.
            </h2>
          </div>
          <div className="relative grid gap-8 md:grid-cols-4">
            <div className="absolute right-0 top-12 hidden h-px w-full bg-gradient-to-l from-transparent via-primary/40 to-transparent md:block" />
            {steps.map((s, i) => (
              <motion.div
                key={s.n}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className="relative text-center"
              >
                <div className="relative mx-auto mb-5 inline-flex h-24 w-24 items-center justify-center rounded-full glass shadow-neon">
                  <s.icon className="h-10 w-10 text-accent" />
                  <span className="absolute -top-2 -right-2 flex h-9 w-9 items-center justify-center rounded-full bg-gradient-neon text-sm font-black text-primary-foreground shadow-glow">
                    {s.n}
                  </span>
                </div>
                <h3 className="mb-2 text-xl font-bold">{s.title}</h3>
                <p className="text-sm text-muted-foreground">{s.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="relative px-6 py-20 md:px-12">
        <div className="mx-auto max-w-7xl">
          <div className="mb-12 text-center">
            <span className="text-sm font-bold tracking-widest text-accent">// آراء اللاعبين</span>
            <h2 className="mt-2 text-4xl font-black md:text-6xl">
              +500 ألف <span className="text-gradient-neon">لاعب سعيد</span>
            </h2>
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            {[
              { n: "أحمد ع.", g: "PUBG", t: "أسرع موقع شحن جربته. وصلتني الـUC قبل ما أكمل أكتب الإيميل!" },
              { n: "ليث م.", g: "Free Fire", t: "الأسعار ممتازة والدعم رد عليّ خلال دقيقتين. صار موقعي الثابت." },
              { n: "سارة ك.", g: "Genshin", t: "الواجهة جميلة جداً والدفع كان سهل. شحنت من الجوال بثوانٍ." },
            ].map((r, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="rounded-3xl glass p-7"
              >
                <div className="mb-4 flex gap-1">
                  {Array.from({ length: 5 }).map((_, j) => (
                    <Star key={j} className="h-5 w-5 fill-gold text-gold" />
                  ))}
                </div>
                <p className="mb-6 text-lg leading-relaxed">"{r.t}"</p>
                <div className="flex items-center gap-3 border-t border-border pt-4">
                  <div className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-neon font-bold text-primary-foreground">
                    {r.n[0]}
                  </div>
                  <div>
                    <div className="font-bold">{r.n}</div>
                    <div className="text-xs text-muted-foreground">لاعب {r.g}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative px-6 py-20 md:px-12">
        <div className="mx-auto max-w-5xl">
          <div className="relative overflow-hidden rounded-[2.5rem] glass p-10 text-center shadow-neon md:p-16">
            <div className="absolute inset-0 bg-gradient-neon opacity-10" />
            <div className="absolute -right-20 -top-20 h-60 w-60 rounded-full bg-primary/30 blur-3xl" />
            <div className="absolute -left-20 -bottom-20 h-60 w-60 rounded-full bg-accent/30 blur-3xl" />
            <div className="relative">
              <Sparkles className="mx-auto mb-4 h-12 w-12 text-accent animate-pulse" />
              <h2 className="text-4xl font-black md:text-6xl">
                جاهز ترفع <span className="text-gradient-neon">مستواك؟</span>
              </h2>
              <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
                سجّل الآن واحصل على خصم 10% على أول عملية شحن، بالإضافة إلى نقاط مكافآت دائمة.
              </p>
              <button className="mt-8 inline-flex items-center gap-2 rounded-full bg-gradient-neon px-10 py-4 font-bold text-primary-foreground shadow-glow transition hover:scale-105 active:scale-95">
                ابدأ الشحن الآن <ChevronLeft className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

function Nav() {
  return (
    <header className="sticky top-0 z-50 backdrop-blur-xl">
      <div className="border-b border-border/50 bg-background/60">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 md:px-12">
          <a href="#" className="flex items-center gap-2">
            <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-neon shadow-glow">
              <Gamepad2 className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="font-display text-2xl">نِيّون</span>
          </a>
          <nav className="hidden items-center gap-8 text-sm font-bold md:flex">
            <a href="#games" className="transition hover:text-accent">الألعاب</a>
            <a href="#" className="transition hover:text-accent">المحفظة</a>
            <a href="#" className="transition hover:text-accent">العروض</a>
            <a href="#" className="transition hover:text-accent">الدعم</a>
          </nav>
          <div className="flex items-center gap-3">
            <button className="hidden rounded-full px-4 py-2 text-sm font-bold transition hover:text-accent md:block">
              دخول
            </button>
            <button className="rounded-full bg-gradient-neon px-5 py-2 text-sm font-bold text-primary-foreground shadow-glow transition hover:scale-105">
              تسجيل
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-30" />
      <img
        src={heroImg}
        alt="ساحة ألعاب نيون"
        width={1920}
        height={1080}
        className="absolute inset-0 h-full w-full object-cover opacity-40"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-background/60 to-background" />

      <div className="relative mx-auto grid max-w-7xl gap-12 px-6 py-20 md:grid-cols-2 md:px-12 md:py-32">
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.7 }}
          className="flex flex-col justify-center"
        >
          <div className="mb-5 inline-flex items-center gap-2 self-start rounded-full glass px-4 py-2 text-xs font-bold">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-accent opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-accent" />
            </span>
            تسليم فوري · أكثر من 200 لعبة
          </div>
          <h1 className="font-display text-5xl leading-tight md:text-7xl lg:text-8xl">
            اشحن. <br />
            العب. <br />
            <span className="text-gradient-neon">انتصر.</span>
          </h1>
          <p className="mt-6 max-w-lg text-lg leading-relaxed text-muted-foreground">
            منصة الشحن الأولى للاعبين العرب. شدات، جواهر، UC، وV-Bucks بأرخص الأسعار وتسليم خلال ثوانٍ.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <button className="inline-flex items-center gap-2 rounded-full bg-gradient-neon px-8 py-4 font-bold text-primary-foreground shadow-glow transition hover:scale-105 active:scale-95">
              <Zap className="h-5 w-5" /> ابدأ الشحن
            </button>
            <a href="#games" className="inline-flex items-center gap-2 rounded-full border border-border glass px-8 py-4 font-bold transition hover:border-accent">
              تصفح الألعاب <ChevronLeft className="h-5 w-5" />
            </a>
          </div>
          <div className="mt-12 grid grid-cols-3 gap-6">
            {[
              { v: "500K+", l: "لاعب" },
              { v: "200+", l: "لعبة" },
              { v: "4.9★", l: "تقييم" },
            ].map((s) => (
              <div key={s.l}>
                <div className="font-display text-3xl text-gradient-neon md:text-4xl">{s.v}</div>
                <div className="text-xs text-muted-foreground">{s.l}</div>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="relative hidden md:block"
        >
          <div className="relative animate-float">
            <div className="absolute -inset-4 rounded-3xl bg-gradient-neon opacity-30 blur-2xl" />
            <div className="relative overflow-hidden rounded-3xl glass shadow-neon">
              <img src={pubg} alt="PUBG" width={768} height={1024} className="h-[520px] w-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <div className="mb-2 inline-flex items-center gap-1 rounded-full bg-gradient-neon px-3 py-1 text-xs font-bold text-primary-foreground">
                  <Flame className="h-3 w-3" /> الأكثر شحناً
                </div>
                <h3 className="font-display text-3xl">PUBG Mobile</h3>
                <p className="text-sm text-muted-foreground">من 60 UC إلى 8100 UC</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function Marquee() {
  const items = ["شحن فوري", "أرخص الأسعار", "دعم 24/7", "دفع آمن", "خصم على الشحنة الأولى", "تسليم بثوانٍ"];
  return (
    <div className="relative overflow-hidden border-y border-border/50 bg-card/40 py-5">
      <div className="flex gap-12 whitespace-nowrap" style={{ animation: "marquee 25s linear infinite" }}>
        {[...items, ...items, ...items].map((t, i) => (
          <div key={i} className="flex shrink-0 items-center gap-3 font-display text-2xl">
            <Sparkles className="h-5 w-5 text-accent" />
            <span className="text-gradient-neon">{t}</span>
          </div>
        ))}
      </div>
      <style>{`@keyframes marquee { from { transform: translateX(0); } to { transform: translateX(50%); } }`}</style>
    </div>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border/50 px-6 py-12 md:px-12">
      <div className="mx-auto grid max-w-7xl gap-10 md:grid-cols-4">
        <div>
          <div className="mb-4 flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-neon">
              <Gamepad2 className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="font-display text-2xl">نِيّون</span>
          </div>
          <p className="text-sm text-muted-foreground">منصة شحن الألعاب الأولى للاعبين العرب.</p>
        </div>
        {[
          { t: "روابط سريعة", l: ["الألعاب", "العروض", "المحفظة", "نقاط المكافآت"] },
          { t: "الدعم", l: ["مركز المساعدة", "تواصل معنا", "حالة الطلب", "استرداد"] },
          { t: "قانوني", l: ["الشروط", "الخصوصية", "ملفات الارتباط", "اتفاقية البائع"] },
        ].map((c) => (
          <div key={c.t}>
            <h4 className="mb-4 font-bold">{c.t}</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              {c.l.map((i) => (
                <li key={i}><a href="#" className="transition hover:text-accent">{i}</a></li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="mx-auto mt-10 flex max-w-7xl flex-col items-center justify-between gap-4 border-t border-border/50 pt-6 text-sm text-muted-foreground md:flex-row">
        <span>© 2026 نِيّون. جميع الحقوق محفوظة.</span>
        <span className="flex items-center gap-2"><Headphones className="h-4 w-4" /> دعم 24/7 بالعربي</span>
      </div>
    </footer>
  );
}
